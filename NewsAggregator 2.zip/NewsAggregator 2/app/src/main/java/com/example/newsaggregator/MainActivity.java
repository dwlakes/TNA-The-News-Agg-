package com.example.newsaggregator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.newsaggregator.databinding.ActivityMainBinding;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {
    Button newbtn;
    ArrayList<String> sources = new ArrayList();
    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Collections.addAll(sources,"NPR","AP");
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //Checks to see if there are selected sources. Redirects to source page if not.
        //checkForSources();
        
        //checks to see if there are sources selected.
        //Redirects to source selection if no sources are selected
        if (sources.size()==0){
            checkForSources();
            //openActivity2();
        } else{

        }
        new doit().execute();
        binding.bottomNavigationView.setOnItemReselectedListener(item ->{
            switch (item.getItemId()){

                case R.id.editFeed:
                    openActivity2();
                    break;
            }
        });

    }

    private ArrayList<String> checkForSources() {
        //Tries to get selected sources from SelectSources activity
        try{
            Bundle bundle = getIntent().getExtras();
            sources = bundle.getStringArrayList("selectedSourcesArray");
            //sends to SelectSource activity if no sources are selected
        } catch (NullPointerException e){
            Toast toast = Toast.makeText(MainActivity.this,"You don't have any sources selected. Let's get you some.",Toast.LENGTH_LONG);
            toast.show();
            //openActivity2();
        }
        return sources;
    }

    public class doit extends AsyncTask<Void, Void, Void> {
        //List of all the articles to be used.
        ArrayList<Article> articlesList = new ArrayList<Article>();
        @Override
        protected Void doInBackground(Void... voids) {

            //Checks which source to scan for
            for (String source:sources){
                if (source.equals("NPR")) {
                    getNprArticles(articlesList);
                }
                if (source.equals("AP")) {
                    getAPArticles(articlesList);
                }
                if (source.equals("Reuters")){
                    getReutersArticles(articlesList);
                }
                if (source.equals("BBC")){
                    getBBCArticles(articlesList);
                }
            }



            Collections.shuffle(articlesList);
            return null;
        }
        
        protected void onPostExecute(Void unused) {
            for(int i=0;i<articlesList.size();i++){
                addButton(articlesList.get(i));
            }

        }

    }


    private void openActivity2() {
        Intent intent = new Intent(this, SelectSources.class);
            startActivity(intent);

    }

    private void getAPArticles(ArrayList<Article> articlesList) {
        Document apDoc = null;
        // Finds AP site and scrapes it
        try {
            apDoc = Jsoup.connect("https://apnews.com/hub/ap-top-news").get();

        } catch (IOException e) {
            e.printStackTrace();
        }
        Elements apElements = apDoc.getElementsByClass("FeedCard");

        for (Element e: apElements){
            Article apArticle = new Article(e.getElementsByAttribute("href").attr("href"),"AP: " + e.getElementsByTag("h2").text(), "AP");
            articlesList.add(apArticle);
        }

    }

    private void getNprArticles(ArrayList<Article> articlesList) {
        Document nprDoc = null;
        // Finds NPR site and scrapes it
        try {
            nprDoc = Jsoup.connect("https://www.npr.org/sections/news/").get();

        } catch (IOException e) {
            e.printStackTrace();
        }
        // searches for articles
        Elements nprHeadlines = nprDoc.getElementsByClass("title");

        //gets link class and headline
        for(Element e : nprHeadlines){
            Article nprArticle = new Article(e.getElementsByAttribute("href").attr("href"),"NPR: " + e.getElementsByAttribute("href").text(), "NPR");
            articlesList.add(nprArticle);
        }
    }
    private void getReutersArticles(ArrayList<Article> articlesList) {
        Document reutersDoc = null;
        try {
            reutersDoc = Jsoup.connect("https://www.reuters.com/news/archive?date=today").get();

        } catch (IOException e) {
            e.printStackTrace();
        }
        Elements pageElements = reutersDoc.getElementsByClass("story-content");

        for(Element e:pageElements){
            Article reutersArticle = new Article("https://reuters.com"+e.getElementsByAttribute("href").attr("href"),"Reuters: "+e.getElementsByClass("story-title").text(),"Reuters");
            articlesList.add(reutersArticle);
        }
    }
    private void getBBCArticles(ArrayList<Article> articlesList) {
        Document bbcDoc = null;
        ArrayList<Article> bbcArticles = new ArrayList<>();
        ArrayList<Article> bbcArticlesDuplicatesRemoved = new ArrayList<>();
        try {
            bbcDoc = Jsoup.connect("https://www.bbc.com/news/stories").get();

        } catch (IOException e) {
            e.printStackTrace();
        }
        Elements pageElements = bbcDoc.getElementsByClass("gs-c-promo-body");

        for(Element e:pageElements){
            //System.out.println("Article: "+e.getElementsByAttribute("href").attr("href"));
            Article bbcArticle = new Article("https://bbc.com"+e.getElementsByAttribute("href").attr("href"),"BBC: "+e.getElementsByAttribute("href").text(),"Reuters");
            bbcArticles.add(bbcArticle);

        }
        /*for (int i = 0; i < bbcArticles.size(); i++) {
            for (int j = i + 1 ; j < bbcArticles.size(); j++) {
                if (bbcArticles.get(i).storyLink.equals(bbcArticles.get(j).storyLink)) {
                    System.out.println("Found duplicate: "+bbcArticles.get(j));
                    break;
                }else{
                    //System.out.println(bbcArticles.get(i));
                }
            }
        }*/

        for (Article article:bbcArticles){
            if(bbcArticlesDuplicatesRemoved.contains(article)){
                //System.out.println("found duplicate: "+a.storyLink);
            }else{
                bbcArticlesDuplicatesRemoved.add(article);
            }
        }
        for(Article article: bbcArticlesDuplicatesRemoved){
            System.out.println(article.storyLink);
        }


    }

    //Creates a button for each articles
    private void addButton(Article article) {
        LinearLayout layout = (LinearLayout) findViewById(R.id.rootLayout);
        newbtn = new Button(this);
        newbtn.setAllCaps(false);
        newbtn.setText(article.storyText);
        newbtn.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);

        layout.addView(newbtn);
        newbtn.setOnClickListener(view -> {
            Uri uri = Uri.parse(String.valueOf(article.storyLink));
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        });

    }
}
