package com.example.newsaggregator;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;

import com.squareup.picasso.Picasso;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class SelectSources<closePopup> extends AppCompatActivity {
    ArrayList<String> selectedSources = new ArrayList<>();
    Switch newSwitch;

    //Private variables below for displaying the bias popup for source
    private AlertDialog.Builder dialogBuilder;
    private AlertDialog dialog;
    private ImageView credibility;
    private ImageView bias;
    private Button readMore;
    private Button closePopup;

    ArrayList<Source> sources = new ArrayList<>();


    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_sources);
        Button selectSourcesButton = findViewById(R.id.selectSourcesButton);

        // calling the action bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Source ap = new Source("AP", "https://mediabiasfactcheck.com/associated-press/", null, null);
        Source npr = new Source("NPR", "https://mediabiasfactcheck.com/npr/", null, null);
        Source bbc = new Source("BBC", "https://mediabiasfactcheck.com/bbc/", null, null);
        Source fox = new Source("Fox", "https://mediabiasfactcheck.com/fox-news-bias/", null, null);
        Source reuters = new Source("Reuters", "https://mediabiasfactcheck.com/reuters/", null, null);

        Collections.addAll(sources, fox,ap,npr,bbc,reuters);

        //Alphabetizes sources
        Collections.sort(sources, Source.sourceNameComparator);
        selectSourcesButton.setOnClickListener(view -> {
            Intent intent = new Intent(SelectSources.this,MainActivity.class);
            intent.putExtra("selectedSourcesArray",selectedSources);
            startActivity(intent);
        });


        new doit().execute();
    }
    public class doit extends AsyncTask<Void, Void, Void>{
        @Override
        protected Void doInBackground(Void... voids) {
            for (Source source : sources) {
                scrapeSource(source);
            }
            
            return null;
        }

        @Override
        protected void onPostExecute(Void unused) {
            //Creates switch and checks on switch for source analysis
            Switch biasSwitch = findViewById(R.id.biasAnalysisSwitch);
            biasSwitch.setChecked(true);
            for (Source source: sources){
                createCheckButton(source, biasSwitch);
            }

            super.onPostExecute(unused);
        }
    }

    private void scrapeSource(Source source) {
        Document sourceDoc = null;
        ArrayList<Elements> linksArray = new ArrayList<>();
        String linkStrings = new String();
        ArrayList<String> credAndBiasArray = new ArrayList<>();
        try {
            sourceDoc = Jsoup.connect(source.link).get();

        } catch (IOException e) {
            e.printStackTrace();
        }

        //gets entry header that contains code for bias and credibility section
        Elements sourceElements = sourceDoc.getElementsByClass("entry-header");

        //finds links in entry-header
        for (Element e:sourceElements){
            linksArray.add(e.getElementsByAttribute("src"));
        }

        linkStrings = linksArray.toString();

        //Parses links from first document into new document
        Document credDoc = Jsoup.parse(linkStrings);

        //Gets image links for bias and credibility
        Elements credLinks = credDoc.getElementsByAttribute("srcset");

        //"Trims" down to just one link for bias and one for credibility
        for (Element e:credLinks){
            credAndBiasArray.add(e.attr("src"));
        }

        source.biasLink = credAndBiasArray.get(0);
        source.credibilityLink = credAndBiasArray.get(1);


    }
    private void createCheckButton(Source source,Switch biasSwitch) {

        newSwitch = new Switch(this);
        newSwitch.setText(source.name);
        newSwitch.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        postCheckBox(newSwitch, source, biasSwitch);

    }
    private void postCheckBox(Switch newSwitch, Source source,Switch biasSwitch) {
        LinearLayout layout = (LinearLayout) findViewById(R.id.rootLayout2);
        layout.addView(newSwitch);
        newSwitch.setOnClickListener(view -> {
            //Adds news source to array for feed if checked
            if (newSwitch.isChecked()) {
                selectedSources.add(newSwitch.getText().toString());
                //If the media analysis switch is checked, displays media analysis
                if (biasSwitch.isChecked()){
                    showBiasAndCredibility(newSwitch,source);
                }
            //Removes source from array for feed
            } else {
                selectedSources.remove(newSwitch.getText().toString());
            }

        });
    }

    //Creates popup for media analysis
    public void showBiasAndCredibility(Switch checkBox, Source source){
        dialogBuilder = new AlertDialog.Builder(this);
        final View popupView = getLayoutInflater().inflate(R.layout.popup,null);

        //Loads scraped bias image link into imageView
        bias = (ImageView) popupView.findViewById(R.id.biasPopup);
        Picasso.with(this).load(source.biasLink).into(bias);

        //Loads scraped credibility image link into imageView
        credibility = (ImageView) popupView.findViewById(R.id.credibilityPopup);
        Picasso.with(this).load(source.credibilityLink).into(credibility);

        readMore = (Button) popupView.findViewById(R.id.readMore);
        closePopup = (Button) popupView.findViewById(R.id.closePopup);
        readMore.setText("Read more about " +selectedSources.toString().replaceAll("\\[|\\]", "")+"'s bias and credibility");

        dialogBuilder.setView(popupView);
        dialog = dialogBuilder.create();
        dialog.show();

        readMore.setOnClickListener(view -> {
            Uri uri = Uri.parse(String.valueOf(source.link));
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        });

        closePopup.setOnClickListener(view -> {
            dialog.dismiss();
        });

    }
}

