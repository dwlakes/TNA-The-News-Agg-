package com.example.newsaggregator;

import java.util.Comparator;

public class Source {
    public String name;
    public String link;
    public String biasLink;
    public String credibilityLink;

    public Source(String name,
                  String link,
                  String biasLink,
                  String credibilityLink){
        this.name=name;
        this.link=link;
        this.biasLink=biasLink;
        this.credibilityLink=credibilityLink;
    }
    public String getName() {
        return name;
    }

    //Alphabetizes sources
    public static Comparator<Source> sourceNameComparator = new Comparator<Source>() {

        public int compare(Source s1, Source s2) {
            String sourceName1 = s1.getName().toUpperCase();
            String sourceName2 = s2.getName().toUpperCase();

            //ascending order
            return sourceName1.compareTo(sourceName2);


        }};

}
