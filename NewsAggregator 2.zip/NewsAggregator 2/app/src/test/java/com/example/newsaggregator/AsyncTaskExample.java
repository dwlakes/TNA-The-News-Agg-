package com.example.newsaggregator;

public class AsyncTaskExample {
}
