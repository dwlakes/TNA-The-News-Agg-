package com.example.newsaggregator;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.Toast;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.Executor;

public class SelectSources<closePopup> extends AppCompatActivity {
    ArrayList<String> selectedSources = new ArrayList<>();
    Switch newSwitch;

    //Private variables below for displaying the bias popup for source
    private AlertDialog.Builder dialogBuilder;
    private AlertDialog dialog;
    private ImageView credibility;
    private ImageView bias;
    private Button readMore;
    private Button closePopup;


    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_sources);
        Button selectSourcesButton = findViewById(R.id.selectSourcesButton);
        Switch biasSwitch = findViewById(R.id.biasAnalysisSwitch);

        // calling the action bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        ArrayList<Source> sources = new ArrayList<>();

        Source ap = new Source("AP", "https://mediabiasfactcheck.com/associated-press/", null, null);
        Source npr = new Source("NPR", "https://mediabiasfactcheck.com/npr/", null, null);
        Source bbc = new Source("BBC", "https://mediabiasfactcheck.com/bbc/", null, null);


        Collections.addAll(sources, ap, npr, bbc);

        //Alphabetizes sources
        Collections.sort(sources, Source.sourceNameComparator);

        for (Source source : sources) {
            createCheckButton(source, biasSwitch);

        }
        selectSourcesButton.setOnClickListener(view -> {
            Intent intent = new Intent(SelectSources.this,MainActivity.class);
            intent.putExtra("selectedSourcesArray",selectedSources);
            System.out.println(selectedSources);
            startActivity(intent);
        });
    }


    private void scrapeSource(Source source) {
        Document sourceDoc = null;
        // Finds AP site and scrapes it
        try {
            sourceDoc = Jsoup.connect("https://mediabiasfactcheck.com/associated-press").get();

        } catch (IOException e) {
            e.printStackTrace();
        }
        Elements sourceElements = sourceDoc.getElementsByClass("entry-class clearfix");
        System.out.println(sourceElements);
    }
    /*Comparator for sorting the list by Student Name*/



    private void postCheckBox(Switch newSwitch, Source source, Switch biasSwitch) {
        LinearLayout layout = (LinearLayout) findViewById(R.id.rootLayout2);
        layout.addView(newSwitch);
        newSwitch.setOnClickListener(view -> {
            if (newSwitch.isChecked()) {
                selectedSources.add(newSwitch.getText().toString());
                if (biasSwitch.isChecked()){
                    showBiasAndCredibility(newSwitch);
                }
            } else {
                selectedSources.remove(newSwitch.getText().toString());
            }

        });
    }

    private void createCheckButton(Source source, Switch biasSwitch) {

        newSwitch = new Switch(this);
        newSwitch.setText(source.name);
        newSwitch.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        postCheckBox(newSwitch, source, biasSwitch);

    }

    public void showBiasAndCredibility(Switch checkBox){
        dialogBuilder = new AlertDialog.Builder(this);
        final View popupView = getLayoutInflater().inflate(R.layout.popup,null);
        credibility = (ImageView) popupView.findViewById(R.id.credibilityPopup);
        bias = (ImageView) popupView.findViewById(R.id.biasPopup);
        readMore = (Button) popupView.findViewById(R.id.readMore);
        closePopup = (Button) popupView.findViewById(R.id.closePopup);
        readMore.setText("Read more about " +selectedSources.toString().replaceAll("\\[|\\]", "")+"'s bias and credibility");

        dialogBuilder.setView(popupView);
        dialog = dialogBuilder.create();
        dialog.show();

        closePopup.setOnClickListener(view -> {
            dialog.dismiss();
        });

    }

}

