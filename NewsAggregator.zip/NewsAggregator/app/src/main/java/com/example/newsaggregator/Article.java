package com.example.newsaggregator;

public class Article {
    String storyLink;
    String storyText;
    String source;

    public Article(String storyLink,
                   String storyText,
                   String source){
        this.storyLink=storyLink;
        this.storyText=storyText;
        this.source=source;
    }
}
