package com.example.newsaggregator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {
Button newbtn;
ArrayList<String> sources = new ArrayList();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Collections.addAll(sources,"NPR","AP");


        //Checks to see if there are selected sources. Redirects to source page if not.
        checkForSources();
        //checks to see if there are sources selected.
        //Redirects to source selection if no sources are selected
        if (sources.size()==0){
            checkForSources();
            openActivity2();
        } else{
            new doit().execute();
        }

    }

    private ArrayList<String> checkForSources() {
        //Tries to get selected sources from SelectSources activity
        try{
            Bundle bundle = getIntent().getExtras();
            sources = bundle.getStringArrayList("selectedSourcesArray");
            //sends to SelectSource activity if no sources are selected
        } catch (NullPointerException e){
            Toast toast = Toast.makeText(MainActivity.this,"You don't have any sources selected. Let's get you some.",Toast.LENGTH_LONG);
            toast.show();
            openActivity2();
        }
        return sources;
    }

    public class doit extends AsyncTask<Void, Void, Void> {
        //List of all the articles to be used.
        ArrayList<Article> articlesList = new ArrayList<Article>();
        @Override
        protected Void doInBackground(Void... voids) {

            //Checks which source to scan for
            for (String source : sources) {
                System.out.println("in background: "+source);
                if (source.equals("NPR")) {
                    System.out.println("found npr");
                    getNprArticles(articlesList);
                }
                if (source.equals("AP")) {
                    getAPArticles(articlesList);
                }
            }



            Collections.shuffle(articlesList);
            //System.out.println(articlesList.get(1).storyLink);
            return null;
        }
        protected void onPostExecute(Void unused) {
            for(int i=0;i<articlesList.size();i++){
                addButton(articlesList.get(i));
            }

        }

    }

    private void openActivity2() {
        Intent intent = new Intent(this, SelectSources.class);
            startActivity(intent);

    }

    private void getAPArticles(ArrayList<Article> articlesList) {
        ArrayList<String> apHeadline = new ArrayList<String>();
        ArrayList<Elements> apStoryLinks = new ArrayList<>();
        ArrayList<String> apStoryDirect= new ArrayList<String>();
        Document apDoc = null;
        // Finds AP site and scrapes it
        try {
            apDoc = Jsoup.connect("https://apnews.com/hub/ap-top-news").get();

        } catch (IOException e) {
            e.printStackTrace();
        }
        Elements apElements = apDoc.getElementsByClass("FeedCard");
        //System.out.println(apElements);

        for (Element e: apElements){
            apHeadline.add(e.getElementsByTag("h2").text());
        }


        for(Element e: apElements){
            apStoryLinks.add(e.getElementsByAttribute("href"));
            //System.out.println("Link"+e);
        }
        //trims down to just the hyper link to the story and adds domain
        for (Elements e : apStoryLinks){
            apStoryDirect.add("http://apnews.com"+e.attr("href"));

        }
        int counter = 0;
        for(String e : apStoryDirect){
            try {
                Article apArticle = new Article(apStoryDirect.get(counter),"AP: " + apHeadline.get(counter), "AP");

                articlesList.add(apArticle);
            } catch (Exception exception) {
                exception.printStackTrace();
            }
            counter++;
        }
    }

    private ArrayList<Article> getNprArticles(ArrayList<Article> articlesList) {
        ArrayList<Elements> nprStoryLinks = new ArrayList<Elements>();
        ArrayList<String> nprStoryDirect= new ArrayList<String>();
        Document nprDoc = null;
        // Finds NPR site and scrapes it
        try {
            nprDoc = Jsoup.connect("https://www.npr.org/sections/news/").get();

        } catch (IOException e) {
            e.printStackTrace();
        }

        // searches for articles
        Elements nprHeadlines = nprDoc.getElementsByClass("title");


        //gets href class and extra stuff
        for(Element e : nprHeadlines){
            nprStoryLinks.add(e.getElementsByAttribute("href"));
        }
        //trims down to just the hyper link to the story
        for (Elements e : nprStoryLinks){
            nprStoryDirect.add(e.attr("href"));

        }

        int counter = 0;
        // Creates article objects and stores them into a list
        for(String e : nprStoryDirect){
            try {
                Article nprArticle = new Article(nprStoryDirect.get(counter),"NPR: " + nprHeadlines.get(counter).text(), "NPR");

                articlesList.add(nprArticle);
            } catch (Exception exception) {
                exception.printStackTrace();
            }
            counter++;
        }
        return articlesList;
    }
    //Creates a button for each articles
    private void addButton(Article article) {
        LinearLayout layout = (LinearLayout) findViewById(R.id.rootLayout);
        newbtn = new Button(this);
        newbtn.setAllCaps(false);
        newbtn.setText(article.storyText);
        newbtn.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);


        layout.addView(newbtn);
        newbtn.setOnClickListener(view -> {
            Uri uri = Uri.parse(String.valueOf(article.storyLink));
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        });

    }
}
