package com.example.newsaggregator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {
Button newbtn;
String words;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        new doit().execute();
    }

    public class doit extends AsyncTask<Void, Void, Void> {
        String nprStoryLink;
        ArrayList<Elements> nprStoryLinks = new ArrayList<Elements>();
        ArrayList<String> nprStoryDirect= new ArrayList<String>();
        ArrayList<Article> articlesList = new ArrayList<Article>();
        ArrayList<String> apHeadline = new ArrayList<String>();
        ArrayList<Elements> apStoryLinks = new ArrayList<>();
        ArrayList<String> apStoryDirect= new ArrayList<String>();
        @Override
        protected Void doInBackground(Void... voids) {
            Document nprDoc = null;
        // Finds NPR site and scrapes it
            try {
                nprDoc = Jsoup.connect("https://www.npr.org/sections/news/").get();

            } catch (IOException e) {
                e.printStackTrace();
            }



            // searches for articles
            Elements elements = nprDoc.getElementsByClass("title");


            //gets href class and extra stuff
            for(Element e : elements){
                nprStoryLinks.add(e.getElementsByAttribute("href"));
            }
            //trims down to just the hyper link to the story
            for (Elements e : nprStoryLinks){
                nprStoryDirect.add(e.attr("href"));

            }

            int counter = 0;
            // Creates article objects and stores them into a list
            for(String e : nprStoryDirect){
                try {
                    Article nprArticle = new Article(nprStoryDirect.get(counter), elements.get(counter).text(), "NPR");

                    articlesList.add(nprArticle);
                } catch (Exception exception) {
                    exception.printStackTrace();
                }
                counter++;
            }
            Document apDoc = null;
            // Finds AP site and scrapes it
            try {
                apDoc = Jsoup.connect("https://apnews.com/hub/ap-top-news").get();

            } catch (IOException e) {
                e.printStackTrace();
            }
            Elements apElements = apDoc.getElementsByClass("FeedCard");
            //System.out.println(apElements);

            for (Element e: apElements){
                apHeadline.add(e.getElementsByClass("cardHeadline").text());
                //System.out.println(e.text());
            }
            System.out.println(apHeadline.get(1));

            for(Element e: apElements){
                apStoryLinks.add(e.getElementsByAttribute("href"));
                //System.out.println("Link"+e);
            }
            //trims down to just the hyper link to the story
            for (Elements e : apStoryLinks){
                apStoryDirect.add("http://apnews.com"+e.attr("href"));

            }
            counter = 0;
            for(String e : apStoryDirect){
                try {
                    Article nprArticle = new Article(apStoryDirect.get(counter), apHeadline.get(counter), "AP");

                    articlesList.add(nprArticle);
                } catch (Exception exception) {
                    exception.printStackTrace();
                }
                counter++;
            }
            Collections.shuffle(articlesList);
            System.out.println(articlesList.get(1).storyLink);
            return null;
        }
        protected void onPostExecute(Void unused) {
            for(int i=0;i<articlesList.size();i++){
                addButton(articlesList.get(i));
            }

        }

    }

    private void addButton(Article article) {
        LinearLayout layout = (LinearLayout) findViewById(R.id.rootLayout);
        newbtn = new Button(this);
        newbtn.setText(article.storyText);

        layout.addView(newbtn);
        newbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse(String.valueOf(article.storyLink));
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            }
        });

    }
}
